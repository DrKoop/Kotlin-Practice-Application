package com.koopdev.kotuno.todoapp

data class Task(val name:String, val category: TaskCategory, var isSelected:Boolean = false){

}