package com.koopdev.kotuno.todoapp

import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.koopdev.kotuno.R
import com.koopdev.kotuno.todoapp.TaskCategory.*

class to_doActivity : AppCompatActivity() {

    private val categories =  listOf(
        Business,
        Personal,
        Other,
    )

    private val tasks = mutableListOf(
        Task("PruebaBussines", Business),
        Task("PruebaPersonal", Personal),
        Task("PruebaOtra", Other)
    )

    private lateinit var recyclerViewCategories: RecyclerView
    private lateinit var categoriesAdapter: CategoriesAdapter
    private lateinit var rvTask:RecyclerView
    private lateinit var tasksAdapter: TaskAdapter
    private lateinit var fabAddTask:FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_to_do)
        inicioReferencias()
        initiUi()
        initListeners()
    }

    private fun initListeners() {
        fabAddTask.setOnClickListener { showDialog() }
    }

    private fun showDialog(){
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_task)
        val btnAddTask:Button = dialog.findViewById(R.id.ButtonAlert)
        val editTask:EditText = dialog.findViewById(R.id.editTask)
        val rgCategories:RadioGroup= dialog.findViewById(R.id.rgCategories)

        btnAddTask.setOnClickListener {
            val currentTask = editTask.text.toString()

            if( currentTask.isNotEmpty() ){
                val selectedId = rgCategories.checkedRadioButtonId
                val selectedRadioButton:RadioButton = rgCategories.findViewById(selectedId)
                val categoriaSeleccionada:TaskCategory =
                    when(selectedRadioButton.text){
                        getString(R.string.alert_business) -> Business
                        getString(R.string.alert_personal) -> Personal
                        else -> Other
                    }
                tasks.add(Task( currentTask , categoriaSeleccionada ))
                updateTask()
                dialog.hide()
            }

        }

        dialog.show()
    }


    private fun inicioReferencias(){
        recyclerViewCategories = findViewById(R.id.recyclerViewCategories)
        rvTask = findViewById(R.id.rvTask)
        fabAddTask = findViewById(R.id.fabAddTask)
    }

    private fun initiUi() {
        categoriesAdapter = CategoriesAdapter(categories) { updateCategories(it) }
        recyclerViewCategories.layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
        recyclerViewCategories.adapter = categoriesAdapter

        tasksAdapter = TaskAdapter(tasks) { position -> onItemSelected(position) }
        rvTask.layoutManager = LinearLayoutManager(this)
        rvTask.adapter = tasksAdapter
    }

    private fun onItemSelected(position:Int){
        tasks[position].isSelected = !tasks[position].isSelected
        updateTask()
    }
    private fun updateCategories( position:Int){
        categories[position].isSelected =  !categories[position].isSelected
        categoriesAdapter.notifyItemChanged(position)
        updateTask()
    }

    //Informa al adaptador que existen nuevos ITEMS
    private fun updateTask(){
        val selectedCategories : List<TaskCategory> = categories.filter { it.isSelected }
        val newTasks = tasks.filter{ selectedCategories.contains(it.category) }
        tasksAdapter.task = newTasks
        tasksAdapter.notifyDataSetChanged()
    }

}