package com.koopdev.kotuno

fun main(){
    var name:String? = "koop" //null  null
    print( name!![1])
    println(name?.get(2) ?: "Valor nullo")
}