package com.koopdev.kotuno.superhero

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {
    @GET("/api/249739330952942/search/{name}")

    //Corrutinas
    suspend fun getSuperHero( @Path("name") superHeroName:String ):Response<SuperHeroDataResponse>

    @GET("/api/249739330952942/{id}")
    suspend fun  getSuperHeroDetail( @Path("id") superHeroID:String ) :Response<SuperHeroDetailResponse>
}