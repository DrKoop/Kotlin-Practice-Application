package com.koopdev.kotuno.superhero

import com.google.gson.annotations.SerializedName

//Se instancia los arboles prinicpales de las propiedades
data class SuperHeroDetailResponse(
    @SerializedName("name") val name: String,
    @SerializedName("powerstats") val powerstats:PowerStatsResponse,
    @SerializedName("image") val image:SuperHeroImageDetailResponse,
    @SerializedName("biography") val biography:Biography,
)

//Instancias  de las propiedades secundarias
data class PowerStatsResponse(
    @SerializedName("intelligence") val intelligence: String,
    @SerializedName("strength") val strength: String,
    @SerializedName("speed") val speed: String,
    @SerializedName("durability") val durability: String,
    @SerializedName("power") val power: String,
    @SerializedName("combat") val combat: String
)

data class SuperHeroImageDetailResponse( @SerializedName("url") val  url:String)

data class Biography(
    @SerializedName("full-name") val fullName:String,
    @SerializedName("publisher") val publisher:String
    )