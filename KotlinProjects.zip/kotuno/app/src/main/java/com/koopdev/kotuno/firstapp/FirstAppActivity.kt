package com.koopdev.kotuno.firstapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import com.koopdev.kotuno.R

class FirstAppActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first_app)
        val  buttonStart = findViewById<AppCompatButton>(R.id.buttonStart)
        val editor = findViewById<AppCompatEditText>(R.id.editorTexto)



        buttonStart.setOnClickListener {

            val editorValue =  editor.text.toString()

            if( editorValue.isNotEmpty() ){
                val intent = Intent(this, ResaultActivity::class.java )
                intent.putExtra("EXTRA_NAME", editorValue)
                startActivity(intent)
            }


        }
    }
}