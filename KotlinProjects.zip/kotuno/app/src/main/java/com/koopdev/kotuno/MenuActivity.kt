package com.koopdev.kotuno

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.koopdev.kotuno.firstapp.FirstAppActivity
import com.koopdev.kotuno.imc.ImcCalculatorActivity
import com.koopdev.kotuno.settings.SettingsActivity
import com.koopdev.kotuno.superhero.SuperHeroListActivity
import com.koopdev.kotuno.todoapp.to_doActivity

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
        val btnSaludar = findViewById<Button>(R.id.btnSaluda)
        val btnImcApp = findViewById<Button>(R.id.btnIMCApp)
        val btnTODO = findViewById<Button>(R.id.btnTODO)
        val btnSuperHero = findViewById<Button>(R.id.btnSuperHero)
        val btnSettings = findViewById<Button>(R.id.btnSettings)

        btnSaludar.setOnClickListener{
            navigate()
        }

        btnImcApp.setOnClickListener { navigatetoToImcApp() }

        btnTODO.setOnClickListener {
            navigateToTODOApp()
        }

        btnSuperHero.setOnClickListener { navigateToSuperHeroApp() }
        btnSettings.setOnClickListener { navigateToSettings() }
    }

    private fun navigateToSettings() {
        val intent = Intent(this, SettingsActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToSuperHeroApp() {
        val intent = Intent(this, SuperHeroListActivity::class.java )
        startActivity(intent)
    }

    private fun navigatetoToImcApp() {
       val intent = Intent(this, ImcCalculatorActivity::class.java )
        startActivity(intent)
    }

    private fun navigate(){
        val intent = Intent(this, FirstAppActivity::class.java )
        startActivity(intent)
    }

    private fun navigateToTODOApp(){
        val intent = Intent( this, to_doActivity::class.java)
        startActivity(intent)
    }
}