package com.koopdev.kotuno.firstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.koopdev.kotuno.R

class ResaultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resault)

        val TetxtResult = findViewById<TextView>(R.id.tyResult)

        val recuperandoValorPantallaPrincipal:String = intent.extras?.getString("EXTRA_NAME").orEmpty()

        TetxtResult.text= "Hola $recuperandoValorPantallaPrincipal"
    }
}