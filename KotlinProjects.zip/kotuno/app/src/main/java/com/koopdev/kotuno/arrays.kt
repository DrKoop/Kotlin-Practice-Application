package com.koopdev.kotuno

fun main(){
    //arrays()
    listas()
}

fun arrays(){
    val week = arrayOf("l", "m", "mm", "j", "v", "s", "d")
    print(week[0])
    //recorrer array
    for( posicion in week.indices){
        println(week[posicion])
    }
    for( w in week){
        println("Ahora es $w")
    }
}


fun listas(){
    val readOnly:List<String> = listOf("l", "m", "mm", "j", "v", "s", "d")
    println(readOnly.size)
    println(readOnly.last())
    var filtrar = readOnly.filter { it.contains("m")}
    print(filtrar)
    //Recorrer la lista
    readOnly.forEach { lista -> println(lista) }

    val listaquesiSepuedeModificar:MutableList<String> = mutableListOf("l", "m", "mm", "j", "v")
    listaquesiSepuedeModificar.add( index = 2 ,"s")
    println(listaquesiSepuedeModificar)
}