package com.koopdev.kotuno.superhero

import com.google.gson.annotations.SerializedName

//Valores  que se van a recuperar del endpoint
data class SuperHeroDataResponse(
    @SerializedName("response") val propiedadEndPoint:String,
    @SerializedName("results") val superheroes: List <SuperheroItemResponse>
)

data class SuperheroItemResponse(
    @SerializedName("id") val superheroID: String,
    @SerializedName("name") val name: String,
    @SerializedName("image") val heroImage:SuperheroImageResponse
    )

data class SuperheroImageResponse( @SerializedName("url") val url:String)