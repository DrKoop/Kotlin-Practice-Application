package com.koopdev.kotuno

fun main(){
    //ifbasico()
    //ifAnidado()
    //ifMultiple()
    //getMonth(mes = 100)
    //mesParoImpar(month = 10)
    semestreDelaño(2)
    result(false)
}

fun ifbasico(){
    val name = "Koop"

    if( name == "nombre"){
        println("el nombre $name es igual")
    }else{
        println("El nombre $name no es igual al de la variable")
    }
}

fun ifAnidado(){
    val mascota = "a"

    if( mascota == "perro"){
        println("Es un perro")
    }else if( mascota== "gato"){
        println("Es un gato")
    }else if( mascota== "pajaro"){
        println("es un pajaro")
    }else{
        println("No es ninguna de las mascotas")
    }
}


fun ifMultiple(){
    var age = 18
    var permission = false

    if( age >= 18){
        if(!permission){
            println("Eres mayor de edad, y puedes tomar")
        }
    }
    if( age >= 18 && !permission){
        println("puedo tomar")
    }
}

fun getMonth(mes:Int){
    when(mes){
        1 -> print("enero")
        2 -> print("febrero")
        3 -> print("marzo")
        4 -> print("abril")
        5 -> print("mayo")
        6 -> print("junio")
        7 -> print("julio")
        8 -> print("agosto")
        9 -> print("septiembre")
        10 -> print("octubre")
        11 -> print("noviembre")
        12 -> print("diciembre")
        else -> print("No es un mes")
    }
}

fun mesParoImpar(month:Int){
    when(month  ){
        1 ,3, 5, 7, 9 ,11-> print("el mes es impar")
        2, 4, 6 , 8 , 10, 12 -> print("el mes es par")
        else -> print("No es un mes")
    }
}

fun semestreDelaño (mes: Int) =

    when(mes) {
        in 1..6 ->  print("estas en el primer semestre del año")
        in 7..12 -> print("estas en el segundo semestre del año")
        !in 1..12 -> print("no se encuentra en el rango")
        else ->  "hello world"
    }



fun result(value:Any){
    when(value){
        is Int -> value + value
        is String -> print(value)
        is Boolean -> if(value) print("Hello World")
    }
}