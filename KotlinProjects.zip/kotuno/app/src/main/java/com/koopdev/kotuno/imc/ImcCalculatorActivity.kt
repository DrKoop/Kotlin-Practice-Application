package com.koopdev.kotuno.imc

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.slider.RangeSlider
import com.koopdev.kotuno.R
import java.text.DecimalFormat

class ImcCalculatorActivity : AppCompatActivity() {

    private var isMaleSelected:Boolean = true
    private var isFeMaleSelected:Boolean = false
    //Peso por defecto
    private var currenWeight:Int = 75
    private var defaultAge:Int = 23
    private var alturaActual:Int = 120

    private lateinit var viewMale:CardView
    private lateinit var viewFemale:CardView

    //Slider
    private lateinit var  tvHeight:TextView
    private lateinit var rangesliderHieght:RangeSlider
    //Botones
    private lateinit var  btnRestar:FloatingActionButton
    private lateinit var  btnSumar:FloatingActionButton
    private lateinit var tvPeso:TextView

    private lateinit var  btnRestarEdad:FloatingActionButton
    private lateinit var  btnSumarEdad:FloatingActionButton
    private lateinit var tvEdad:TextView

    private lateinit var btnCalcular:Button

    //Creando Constantes para comunicar 2 activity
    companion object{
        const val IMC_KEY = "IMC_RESAULT"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imc_calculator2)
        initComponents()
        initListeners()
        initUI()
    }




    //Solo inicializa las vistas
    private fun initComponents(){
        viewMale = findViewById(R.id.viewMale)
        viewFemale = findViewById(R.id.viewFemale)
        rangesliderHieght = findViewById(R.id.rangesliderHieght)
        tvHeight = findViewById( R.id.tvHeight )
        tvPeso = findViewById(R.id.tvPeso)
        btnRestar = findViewById(R.id.restarPeso)
        btnSumar = findViewById(R.id.sumarPeso)
        tvEdad = findViewById(R.id.tvEdad)
        btnRestarEdad = findViewById(R.id.restarEdad)
        btnSumarEdad = findViewById(R.id.sumarEdad)
        btnCalcular = findViewById(R.id.btnCalcular)

    }


    private fun initListeners() {
        viewMale.setOnClickListener {
            changeGender()
            setGendercolor()
        }
        viewFemale.setOnClickListener {
            changeGender()
            setGendercolor()
        }

        rangesliderHieght.addOnChangeListener{ _, value, _ ->
            val dateFormat = DecimalFormat("#.##")
            alturaActual = dateFormat.format(value).toInt()
            tvHeight.text = "$alturaActual cm"
        }

        btnSumar.setOnClickListener{
            currenWeight = currenWeight + 1
            setWeight()
        }
        btnRestar.setOnClickListener {
            currenWeight = currenWeight - 1
            setWeight()
        }
        btnSumarEdad.setOnClickListener {
            defaultAge = defaultAge + 1
            setAge()
        }

        btnRestarEdad.setOnClickListener {
            defaultAge = defaultAge - 1
            setAge()
        }

        btnCalcular.setOnClickListener {
           val result =  calcularIMC()
            navigateToResault(result)
        }


    }

    private fun navigateToResault(result: Double) {
        val intent = Intent(this, ResaultIMCActivity::class.java)
        intent.putExtra(IMC_KEY, result)
        startActivity(intent)
    }

    private fun calcularIMC():Double{
        val formatNumber = DecimalFormat("#.##")
        val imc = currenWeight / (alturaActual.toDouble()/100 * alturaActual.toDouble()/100)
        return formatNumber.format(imc).toDouble()
        //Log.i("resultado", "el imc es : $result")
    }

    private fun setAge(){
        tvEdad.text = defaultAge.toString()
    }

    private fun setWeight(){
        tvPeso.text = currenWeight.toString()
    }

    private fun changeGender(){
        isMaleSelected = !isMaleSelected
        isFeMaleSelected = !isFeMaleSelected
    }

    private fun setGendercolor(){
        viewMale.setCardBackgroundColor( getBackgroundColor(isMaleSelected) )
        viewFemale.setCardBackgroundColor( getBackgroundColor(isFeMaleSelected) )
    }

    private fun getBackgroundColor(isSelectedComponent:Boolean):Int{

        var colorReference = if(isSelectedComponent){
            R.color.background_component_selected
        }else{
            R.color.background_component
        }

        return ContextCompat.getColor(this, colorReference)
    }


    private fun initUI() {
        setGendercolor()
        setWeight()
        setAge()
    }

}