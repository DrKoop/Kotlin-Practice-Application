package com.koopdev.kotuno



fun main(){
    // (Valores) estatico (Una constante)
    val age:Int = 30
    //valor Dinamico, (Variable)
    var age2:Int = 30
    //println(age2)
    age2 = 50
    //print(age2 % age)

    //Mayor espacio en memoria
    val num:Long = 40000000
    //float admite 6 decimales unicamente
    val deCimales:Float = 33.33f

    var exampleDatosCombinados = age * deCimales
    //println(exampleDatosCombinados)

    //Mas memoria para deimales, pero ocupa mas memoria, double ocupa 12 caracateres
    val excampledouble:Double = 2222.21

    //Variables Alfanumericas
    //Soporta un caracter , numero, alfa, entero,se especifica entre comillas simples
    val charExample:Char = 'a'



    //String se especifica con comillas dobles => no tiene un limite
    val stringExample:String = "Hola Mundo"


    //print(deCimales)

    showMyname(name = "Dr koop")
    showMyAge()
    suma(3 ,7)
    //resta(uno = 10, dos = 4)
    val restando = resta(uno = 10, dos = 4)
    println(restando)
}

fun showMyname(name:String){
    println("Mi nombre es $name")
}
//Funcion con valores por DEFECTO
fun showMyAge(edadActual:Int=24){
    println("mi edad es $edadActual")
}
fun suma(uno:Int, dos:Int){
    println(uno + dos)
}
//Parametros de Salida => Funciones que devuelvan especificamente solo un valory especificar de que tipo es

fun resta(uno:Int, dos:Int):Int{
    return uno - dos
}